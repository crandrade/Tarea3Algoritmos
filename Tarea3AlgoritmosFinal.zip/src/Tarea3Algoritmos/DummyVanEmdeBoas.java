package Tarea3Algoritmos;

public class DummyVanEmdeBoas extends GenericTree {

	public DummyVanEmdeBoas(){}

	@Override
	public GenericNode find(int key) {
		return null;
	}
	@Override
	public void insert(int key, int value){}
	@Override
	public void delete(int key){}
}
